﻿namespace LibraryManagement.Api.Models.Common
{
    public class ApiResponse
    {
    }
}
