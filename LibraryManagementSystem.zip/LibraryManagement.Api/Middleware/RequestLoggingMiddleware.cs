﻿namespace LibraryManagement.Api.Middleware
{
    public class RequestLoggingMiddleware
    {
    }
}
