﻿namespace LibraryManagement.Infrastructure.Services
{
    public class DateTimeService
    {
        public DateTime UtcNow => DateTime.UtcNow;
    }
}
