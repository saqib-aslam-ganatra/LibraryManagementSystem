﻿namespace LibraryManagement.Api.Extensions
{
    public class ServiceCollectionExtensions
    {
    }
}
