﻿namespace LibraryManagement.Api.Extensions
{
    public class ApplicationBuilderExtensions
    {
    }
}
